from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from subprocess import PIPE
import subprocess
import os
from django.template import RequestContext
import time
from subprocess import CREATE_NEW_CONSOLE


def catalogoperation(request):
    print ("Calling the operation");
    print(request.POST)
    url = request.POST.get('url')
    username = request.POST.get("username")
    apikey = request.POST.get("apikey")
    ip = request.POST.get("ip")
    os = request.POST.get("os")
    privateservice = request.POST.get('private_services')
    print (privateservice)
    tradservice = request.POST.get('traditional_services')
    print (tradservice)
    out = ""
    context = []
    result = []
    servicelist = []
    'If block for Upload '
    #print(request.POST)
    if (request.POST.get("button") == "upload"):
        
        if(tradservice == 'all') :
            print ("Inside else block" + tradservice)
            process = subprocess.Popen(["bash", "setup.sh", url, username, apikey], stdout=PIPE)
            out, err = process.communicate() 
        elif (tradservice == 'none'):
            print ('noop')    
        else:
            print ("Inside else block" + tradservice)
            process = subprocess.Popen(["bash", "setup.sh", url, username, apikey,tradservice.upper()], stdout=PIPE)
            out, err = process.communicate()
        print (out) 
        
        services = str(out).split('\\n')
        count = 0
        while count+11 < len(services):
            service_name =  services[count+3].split('-')[1].strip()
            if 'exist' in services[count+5]:
               result.append({"servicename":service_name,"status":"Already Exist"})
            else:
               result.append({"servicename":service_name,"status":"success"})
            count +=8
    
        if(privateservice == 'all') :
             process = subprocess.Popen(["bash", "setup.sh", url, username, apikey], stdout=PIPE)
             out, err = process.communicate()  
        elif (privateservice == 'none'):
            print ('noop')
        else:
            print ("Inside else block" + privateservice)
            process = subprocess.Popen(["bash", "setup.sh", url, username, apikey,privateservice.upper()], stdout=PIPE)
            out, err = process.communicate()              
        print (out) 
        
        services = str(out).split('\\n')
        count = 0
        while count+11 < len(services):
            service_name =  services[count+3].split('-')[1].strip()
            if 'exist' in services[count+5]:
               result.append({"servicename":service_name,"status":"Already Exist"})
            else:
               result.append({"servicename":service_name,"status":"success"})
            count +=8
               
    elif request.POST.get("button") == "delete":
        
        print ("Inside the delete");
        if(tradservice == 'all') :
            print ("Inside else block" + tradservice)
            process = subprocess.Popen(["bash", "delete_catalogs.sh", url, username, apikey], stdout=PIPE)
            out, err = process.communicate() 
        elif (tradservice == 'none'):
            print ('noop')    
        else:
            print ("Inside else block deleting " + tradservice)
            process = subprocess.Popen(["bash", "delete_catalogs.sh", url, username, apikey,tradservice.upper()], stdout=PIPE)
            out, err = process.communicate()
        print (out) 
    
        if(privateservice == 'all') :
             process = subprocess.Popen(["bash", "delete_catalogs.sh", url, username, apikey], stdout=PIPE)
             out, err = process.communicate()  
        elif (privateservice == 'none'):
            print ('noop')
            
        else:
            print ("Inside else block deleting" + privateservice)
            process = subprocess.Popen(["bash", "delete_catalogs.sh", url, username, apikey,privateservice.upper()], stdout=PIPE)
            out, err = process.communicate()
                    
        print (out)  
  
        print ("Successful after")
        
        print ("Types..."+(str(out)))
         
        '''service_name = str(out).split('\\n')[3].split('-')[1].strip()
        
        if 'exist' in str(out).split('\\n')[5]:
            result.append({"servicename":service_name,"status":"Already Exist"})
        else:
            result.append({"servicename":service_name,"status":"success"})'''
    
    '''if(tradservice != 'all' or privateservice !='all') :
        servicelist.append(privateservice)
        servicelist.append(tradservice)
    for service in servicelist:
        print(service)
        result.append({"servicename":service,"status":"success"})'''
    
    #return render(request,'result.html', {'context':context})
    context.append(result)
    print (context)
    return render(request,'result.html', {'context':context[0]})
        
def cataloghome(request):
    #process = subprocess.Popen(["dir"], stdout=PIPE)
    #out, err = process.communicate()
    #print (out)
    #print (err)
    context = {}
    return render(request,'index.html', {'context':context})



def renderIcd(request):
    #process = subprocess.Popen(["dir"], stdout=PIPE)
    #out, err = process.communicate()
    #print (out)
    #print (err)
    
    process = subprocess.Popen(["git","clone","https://f4a10f6f65b9e6e41f744d96c4265a7cee265795@github.ibm.com/FE-Agents/fe-evry-icd-catalog.git"], stdout=PIPE)
   
    output = process.communicate()[0]
    print (output)
   
    context = []
    private_svc_dir = []
    traditional_svc_dir = []
    private_services = os.listdir("fe-evry-icd-catalog/Services/Private_Cloud")
    for each in private_services:
        
        if  ('xlsx' in each):
            print ("contains xlsx")
            print (each)
        else:
            private_svc_dir.append({'id':each,'value':os.listdir("fe-evry-icd-catalog/Services/Private_Cloud/" + each)[0].split('.')[0]})
            print ("without xlsx")
            print (each)
    traditional_services = os.listdir("fe-evry-icd-catalog/Services/Traditional_IT")
    for each in traditional_services:
        
        if  ('xlsx' in each):
            print ("contains xlsx")
            print (each)
        else:
            traditional_svc_dir.append({'id':each,'value':os.listdir("fe-evry-icd-catalog/Services/Traditional_IT/" + each)[0].split('.')[0]})
            print ("without xlsx")
            print (each)
    context.append({'private_services':private_svc_dir,'traditional_services':traditional_svc_dir})
    return render(request,'catalogoperations.html', {'context':context})
    #return HttpResponse("catalogoperations.html",{'context':context})
    


