from django.apps import AppConfig


class CatalogconfigConfig(AppConfig):
    name = 'catalogconfig'
